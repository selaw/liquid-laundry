<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              <img src="<?php echo base_url(); ?>assets/img/logo/icon.png" alt="logo" width="120" class="shadow-light rounded-circle">
            </div>

             <?= $this->session->flashdata('pesan'); ?> 
              
            <div class="card card-primary">
              <div class="card-header"><h4>Login</h4>
              </div>

              <div class="card-body">
                <form class="needs-validation" method="post" action="<?= base_url('auth'); ?>">
                  <div class="form-group">
                    <input id="email" type="email" class="form-control" name="email" tabindex="1" placeholder="Email" value="<?= set_value('email'); ?>" autofocus>
                    <?= form_error('email',' <small class="text-danger pl-3">','</small>'); ?>

                    <div class="invalid-feedback">
                      Isikan Email anda dengan Benar
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="d-block">
                      
                    <input id="password" type="password" class="form-control" name="password" tabindex="2" placeholder="Password" value="<?= set_value('password'); ?>">
                    <?= form_error('password',' <small class="text-danger pl-3">','</small>'); ?>
                    <div class="invalid-feedback">
                      Isikan password anda
                    </div>
                    <div class="float-right">
                        <a href="<?php echo base_url(); ?>auth/forgot" class="text-small">
                          Forgot Password?
                        </a>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                      Login
                    </button>
                  </div>
                </form>

              </div>
            </div>
            <div class="mt-5 text-muted text-center">
              Don't have an account? <a href="<?php echo base_url(); ?>auth/register">Create One</a>
            </div>
            <div class="simple-footer">
              Copyright &copy; Stisla
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $this->load->view('dist/_partials/js'); ?>